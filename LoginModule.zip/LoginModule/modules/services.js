'use strict';
 
myAngularApp.factory('remoteCallService',function($http){
    var remoteCall = {};

    /* Function : remoteCall.post
    Desc : get values from param and validate, internally http call done to get User details from JSON.
    param : URL - internal file, myLoginData - formData, callBack - return
    Return : callback - result return    */
    remoteCall.post = function (URL,myLoginData,callback) {
        var finalResult             = {};
        var matchingValue           = {};
        var isCredentialsMatched    = false;
        var username    = myLoginData.data.username;
        var pwd         = myLoginData.data.password;

        $http.post(URL, myLoginData).success(function (data, status, headers, config) {
            angular.forEach(data,function(val){
                if(val.userId === username && val.password === pwd){
                    isCredentialsMatched = true;
                    matchingValue = val;
                }
            });
            finalResult = isCredentialsMatched ? {status:200,data:matchingValue,desc:"SUCCESS"} : {status:0,data:"",desc:"Username and Password is not matching"};
            callback(finalResult);
        }).error(function (error, status){
            finalResult = {status:0,data:"",desc:"Internal Server Error"};
        });
    };

    return remoteCall;
  });