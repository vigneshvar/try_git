'use strict';
 
myAngularApp.controller('LoginController',['$scope', 'remoteCallService','$location',
    function ($scope, remoteCallService,$location) {
        $scope.formName = "loginForm";

        /* Function : getLoginValidate()
        Desc: this method is to get values from form-field and call the service to validate with given credentials
        Param: none
        Return: none */
        $scope.getLoginValidate = function () {
            $scope.dataLoading = true;
            var requestURL = "json/userdetails.json";

            if($scope[$scope.formName].$valid){
                $scope.loginParams = {
                    username : angular.isDefined($scope.username) ? $scope.username : "",
                    password : angular.isDefined($scope.password) ? $scope.password : ""
                };
                remoteCallService.post(requestURL,{data:$scope.loginParams},function(response) {
                    if(response.status == 200) {
                        $location.path('/home');
                    } else {
                        $scope.error = response.desc;
                        $scope.dataLoading = false;
                    }
                });
            }
            else{
                $scope.error = "Check Field data";
            }
        };
    }]);