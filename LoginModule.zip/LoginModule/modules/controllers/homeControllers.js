'use strict';
 
myAngularApp.controller('HomeController',
    ['$scope',
    function ($scope) {
      
    }]);