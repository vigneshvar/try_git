'use strict';

var myAngularApp = angular.module('myLoginApp', ['ngRoute']);
 
myAngularApp.config(['$routeProvider', function ($routeProvider) {
    $routeProvider
        .when('/login', {
            controller: 'LoginController',
            templateUrl: 'modules/views/login.html'
        })
        .when('/home', {
            controller: 'HomeController',
            templateUrl: 'modules/views/home.html'
        }) 
        .otherwise({ redirectTo: '/login' });
}]);